/**
 * @file gestor_antenas.h
 * @brief Interface para gestão de antenas de rádio e efeitos de interferência
 * 
 * Este módulo fornece todas as estruturas e funções necessárias para:
 * - Criar e manipular um sistema de antenas
 * - Calcular e visualizar efeitos de interferência
 * - Gerenciar persistência em arquivos texto e binários
 * 
 * @details O sistema utiliza:
 * - Listas ligadas para armazenamento eficiente
 * - Matrizes esparsas para representação espacial
 * - Algoritmos para cálculo de padrões de interferência
 * 
 * @version 1.0
 * @date 2025-03-30
 */

 #ifndef GESTOR_ANTENAS_H
 #define GESTOR_ANTENAS_H
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <stdbool.h>
 #include <time.h>
 #include <stddef.h>
 
 #ifdef _MSC_VER
 typedef long ssize_t;
 #endif
 
 /**
 * @def CHAR_VAZIO
 * @brief Carácter que representa uma célula vazia no sistema 
 * @value '.' Carácter padrão para posições sem antenas
 */
 #define CHAR_VAZIO '.'
 /**
 * @def CHAR_EFEITO
 * @brief Carácter que representa um efeito de interferência no sistema
 * @value '#' Carácter padrão para marcar pontos de interferência
 */
 #define CHAR_EFEITO '#'
 /**
 * @struct Antena
 * @brief Estrutura fundamental que representa uma antena no sistema
 * 
 * Cada antena possui:
 * - Uma frequência característica
 * - Posição definida por linha e coluna
 * - Ligação para próxima antena na lista
 */
typedef struct Antena {
    char frequencia;        /**< Carácter que identifica a frequência da antena */
    int linha;              /**< Posição vertical no sistema (0-indexada) */
    int coluna;             /**< Posição horizontal no sistema (0-indexada) */
    struct Antena* proximo; /**< Ponteiro para próxima antena na lista ligada */
} Antena;
/**
 * @struct EfeitoNefasto
 * @brief Registra um ponto de interferência no sistema
 * 
 * Armazena:
 * - Localização do efeito
 * - Frequência que causou a interferência
 * - Ligação para próximo efeito na lista
 */
typedef struct EfeitoNefasto {
    int linha;                  /**< Linha onde ocorre o efeito */
    int coluna;                 /**< Coluna onde ocorre o efeito */
    char frequencia_origem;     /**< Frequência que causou o efeito */
    struct EfeitoNefasto* proximo; /**< Próximo efeito na lista ligada */
} EfeitoNefasto;
/**
 * @struct CelulaMatriz
 * @brief Implementação de célula para matriz esparsa
 * 
 * Permite representação eficiente de matrizes grandes e esparsas,
 * armazenando apenas as posições que contêm valores relevantes.
 */
typedef struct CelulaMatriz {
    int linha;              /**< Posição vertical na matriz */
    int coluna;             /**< Posição horizontal na matriz */
    char valor;             /**< Valor armazenado na célula */
    struct CelulaMatriz* proximo; /**< Próxima célula não-vazia */
} CelulaMatriz;
 
 /**
 * @struct LinhaArquivo
 * @brief Auxiliar para leitura de arquivos de configuração
 * 
 * Armazena linhas de arquivo texto temporariamente durante o
 * processo de carregamento do sistema.
 */
typedef struct LinhaArquivo {
    char* conteudo;         /**< Texto completo da linha */
    struct LinhaArquivo* proximo; /**< Próxima linha do arquivo */
} LinhaArquivo;
 
/**
 * @struct Ponto
 * @brief Representa uma coordenada 2D no sistema
 * 
 * Utilizado principalmente para cálculo e armazenamento temporário
 * de posições de efeitos de interferência.
 */
typedef struct Ponto {
    int linha;          /**< Coordenada vertical */
    int coluna;         /**< Coordenada horizontal */
    struct Ponto* proximo; /**< Próximo ponto na lista ligada */
} Ponto;
 

 /* Protótipos das funções */
 Antena* inserirAntena(Antena* cabeca, char frequencia, int linha, int coluna);
 Antena* removerAntena(Antena* cabeca, int linha, int coluna, bool* sucesso);
 int calcularLinhas(Antena* cabeca);
 int calcularColunas(Antena* cabeca);
 int mostrarMatrizAntenas(Antena* cabeca);
 int mostrarMatrizComEfeitos(Antena* cabeca);
 int mostrarApenasEfeitos(Antena* cabeca);
 Antena* liberarAntenas(Antena* cabeca);
 EfeitoNefasto* liberarEfeitos(EfeitoNefasto* cabeca);
 CelulaMatriz* liberarCelulasMatriz(CelulaMatriz* cabeca);
 Antena* carregarArquivo(bool* success, char* message);
 int exportarArquivo(Antena* cabeca);
 CelulaMatriz* criarCelulaMatriz(int linha, int coluna, char valor);
 CelulaMatriz* buscarCelula(CelulaMatriz* cabeca, int linha, int coluna);
 CelulaMatriz* atualizarCelula(CelulaMatriz* cabeca, int linha, int coluna, char valor);
 LinhaArquivo* liberarLinhasArquivo(LinhaArquivo* cabeca);
 bool salvarEstadoBinario(Antena *cabeca, char *nomeArquivo);
 Antena* carregarEstadoBinario();
 Ponto* criarPonto(int linha, int coluna);
 Ponto* calcularPontosEfeito(int linha1, int col1, int linha2, int col2);
 Ponto* liberarPontos(Ponto* cabeca);
 
 #endif /* GESTOR_ANTENAS_H */