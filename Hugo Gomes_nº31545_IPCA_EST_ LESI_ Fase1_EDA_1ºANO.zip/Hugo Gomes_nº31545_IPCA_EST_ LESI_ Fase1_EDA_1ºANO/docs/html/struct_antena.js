var struct_antena =
[
    [ "coluna", "struct_antena.html#ad28f77663b945c81f26e84c1b62cb63f", null ],
    [ "frequencia", "struct_antena.html#a98d94cd90b6d9288fc867dbe7a6b6f41", null ],
    [ "linha", "struct_antena.html#a2913fa9623f812bffff810528877ee24", null ],
    [ "proximo", "struct_antena.html#a6469f22ec7999b3c664c703ab46d7a1d", null ]
];