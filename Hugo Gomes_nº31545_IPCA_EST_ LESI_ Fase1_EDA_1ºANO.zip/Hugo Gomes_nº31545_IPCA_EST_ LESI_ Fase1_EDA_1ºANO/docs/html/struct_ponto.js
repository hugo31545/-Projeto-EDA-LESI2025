var struct_ponto =
[
    [ "coluna", "struct_ponto.html#ac420d9f1dfe65e3363855d8cca4ea5ab", null ],
    [ "linha", "struct_ponto.html#a5fe72311c49decf58b5dc8d2e1b38467", null ],
    [ "proximo", "struct_ponto.html#acc5d3fa1f6f0ad9427eb53d9dca9915f", null ]
];