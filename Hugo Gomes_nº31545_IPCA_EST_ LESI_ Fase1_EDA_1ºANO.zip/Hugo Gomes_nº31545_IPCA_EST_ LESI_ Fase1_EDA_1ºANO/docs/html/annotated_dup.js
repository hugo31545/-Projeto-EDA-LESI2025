var annotated_dup =
[
    [ "Antena", "struct_antena.html", "struct_antena" ],
    [ "CelulaMatriz", "struct_celula_matriz.html", "struct_celula_matriz" ],
    [ "EfeitoNefasto", "struct_efeito_nefasto.html", "struct_efeito_nefasto" ],
    [ "LinhaArquivo", "struct_linha_arquivo.html", "struct_linha_arquivo" ],
    [ "Ponto", "struct_ponto.html", "struct_ponto" ]
];