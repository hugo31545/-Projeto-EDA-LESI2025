var struct_efeito_nefasto =
[
    [ "coluna", "struct_efeito_nefasto.html#ade4340ea6b7e36c321d26a0e2b991486", null ],
    [ "frequencia_origem", "struct_efeito_nefasto.html#a20ddf00c8cad5f5f3173531f8f92a19e", null ],
    [ "linha", "struct_efeito_nefasto.html#aeadb92d6800dc1c6dfe48789d7fbd274", null ],
    [ "proximo", "struct_efeito_nefasto.html#a694184b6e9fe6e52e6e2c729ef739b7f", null ]
];