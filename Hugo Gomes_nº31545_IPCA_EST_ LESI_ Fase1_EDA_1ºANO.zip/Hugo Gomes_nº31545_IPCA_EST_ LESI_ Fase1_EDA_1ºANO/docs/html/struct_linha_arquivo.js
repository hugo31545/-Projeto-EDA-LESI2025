var struct_linha_arquivo =
[
    [ "conteudo", "struct_linha_arquivo.html#a0a0f186010491f7d89022836f19d3b88", null ],
    [ "proximo", "struct_linha_arquivo.html#a56603ee179493b90695030272ec9c262", null ]
];