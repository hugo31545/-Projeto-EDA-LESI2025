var searchData=
[
  ['main_0',['main',['../estruturadedados4_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'estruturadedados4.c']]],
  ['mostrarapenasefeitos_1',['mostrarApenasEfeitos',['../estruturadedados4_8c.html#ac9fda55d78ecc615a087106a13a9c374',1,'mostrarApenasEfeitos(Antena *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#ac9fda55d78ecc615a087106a13a9c374',1,'mostrarApenasEfeitos(Antena *cabeca):&#160;estruturadedados4.c']]],
  ['mostrarmatrizantenas_2',['mostrarMatrizAntenas',['../estruturadedados4_8c.html#ae584f4e122d4e86981562acfcd48e7bd',1,'mostrarMatrizAntenas(Antena *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#ae584f4e122d4e86981562acfcd48e7bd',1,'mostrarMatrizAntenas(Antena *cabeca):&#160;estruturadedados4.c']]],
  ['mostrarmatrizcomefeitos_3',['mostrarMatrizComEfeitos',['../estruturadedados4_8c.html#ad35a4ee63b784b299dbcdabaee6d750a',1,'mostrarMatrizComEfeitos(Antena *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#ad35a4ee63b784b299dbcdabaee6d750a',1,'mostrarMatrizComEfeitos(Antena *cabeca):&#160;estruturadedados4.c']]]
];
