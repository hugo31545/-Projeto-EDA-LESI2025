var searchData=
[
  ['removerantena_0',['removerAntena',['../estruturadedados4_8c.html#a6fe64e1b1181d266b30818f28794018c',1,'removerAntena(Antena *cabeca, int linha, int coluna, bool *sucesso):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#a6fe64e1b1181d266b30818f28794018c',1,'removerAntena(Antena *cabeca, int linha, int coluna, bool *sucesso):&#160;estruturadedados4.c']]]
];
