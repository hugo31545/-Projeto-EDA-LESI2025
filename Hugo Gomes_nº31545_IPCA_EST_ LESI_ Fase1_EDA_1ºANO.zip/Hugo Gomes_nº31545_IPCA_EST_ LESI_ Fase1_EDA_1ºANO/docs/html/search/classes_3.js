var searchData=
[
  ['linhaarquivo_0',['LinhaArquivo',['../struct_linha_arquivo.html',1,'']]]
];
