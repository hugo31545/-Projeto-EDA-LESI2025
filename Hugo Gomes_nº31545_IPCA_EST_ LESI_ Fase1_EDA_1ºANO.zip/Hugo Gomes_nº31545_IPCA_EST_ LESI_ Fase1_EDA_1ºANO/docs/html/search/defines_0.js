var searchData=
[
  ['char_5fefeito_0',['CHAR_EFEITO',['../gestor__antenas_8h.html#a858cf39041876902ea9809a7cdb85042',1,'gestor_antenas.h']]],
  ['char_5fvazio_1',['CHAR_VAZIO',['../gestor__antenas_8h.html#ad4f5b6f0375975d10e5d1c722f080d1f',1,'gestor_antenas.h']]]
];
