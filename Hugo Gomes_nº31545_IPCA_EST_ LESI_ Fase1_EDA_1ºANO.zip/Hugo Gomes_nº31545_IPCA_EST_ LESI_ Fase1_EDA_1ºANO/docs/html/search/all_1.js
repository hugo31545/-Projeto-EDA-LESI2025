var searchData=
[
  ['buscarcelula_0',['buscarCelula',['../estruturadedados4_8c.html#af5a346bd36aefc3b375181cf674c87be',1,'buscarCelula(CelulaMatriz *cabeca, int linha, int coluna):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#af5a346bd36aefc3b375181cf674c87be',1,'buscarCelula(CelulaMatriz *cabeca, int linha, int coluna):&#160;estruturadedados4.c']]]
];
