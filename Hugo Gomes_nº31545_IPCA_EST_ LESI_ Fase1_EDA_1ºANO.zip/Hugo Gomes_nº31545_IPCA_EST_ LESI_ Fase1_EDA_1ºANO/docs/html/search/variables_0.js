var searchData=
[
  ['coluna_0',['coluna',['../struct_antena.html#ad28f77663b945c81f26e84c1b62cb63f',1,'Antena::coluna'],['../struct_efeito_nefasto.html#ade4340ea6b7e36c321d26a0e2b991486',1,'EfeitoNefasto::coluna'],['../struct_celula_matriz.html#a11c4cc646b9fa62254676dfb660a9c6b',1,'CelulaMatriz::coluna'],['../struct_ponto.html#ac420d9f1dfe65e3363855d8cca4ea5ab',1,'Ponto::coluna']]],
  ['conteudo_1',['conteudo',['../struct_linha_arquivo.html#a0a0f186010491f7d89022836f19d3b88',1,'LinhaArquivo']]]
];
