var searchData=
[
  ['ponto_0',['Ponto',['../struct_ponto.html',1,'Ponto'],['../gestor__antenas_8h.html#a1a0eed3a220c1dedd4fb9e317b3e6317',1,'Ponto:&#160;gestor_antenas.h']]],
  ['proximo_1',['proximo',['../struct_antena.html#a6469f22ec7999b3c664c703ab46d7a1d',1,'Antena::proximo'],['../struct_efeito_nefasto.html#a694184b6e9fe6e52e6e2c729ef739b7f',1,'EfeitoNefasto::proximo'],['../struct_celula_matriz.html#af5412e6e09c90fafdcbfaa448bd1712f',1,'CelulaMatriz::proximo'],['../struct_linha_arquivo.html#a56603ee179493b90695030272ec9c262',1,'LinhaArquivo::proximo'],['../struct_ponto.html#acc5d3fa1f6f0ad9427eb53d9dca9915f',1,'Ponto::proximo']]]
];
