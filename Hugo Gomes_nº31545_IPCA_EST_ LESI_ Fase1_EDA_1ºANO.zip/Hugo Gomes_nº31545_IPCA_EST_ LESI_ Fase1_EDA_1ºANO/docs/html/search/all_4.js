var searchData=
[
  ['frequencia_0',['frequencia',['../struct_antena.html#a98d94cd90b6d9288fc867dbe7a6b6f41',1,'Antena']]],
  ['frequencia_5forigem_1',['frequencia_origem',['../struct_efeito_nefasto.html#a20ddf00c8cad5f5f3173531f8f92a19e',1,'EfeitoNefasto']]]
];
