var searchData=
[
  ['linha_0',['linha',['../struct_antena.html#a2913fa9623f812bffff810528877ee24',1,'Antena::linha'],['../struct_efeito_nefasto.html#aeadb92d6800dc1c6dfe48789d7fbd274',1,'EfeitoNefasto::linha'],['../struct_celula_matriz.html#a0f8ee250e8214f36b77da2fb6e5d4b94',1,'CelulaMatriz::linha'],['../struct_ponto.html#a5fe72311c49decf58b5dc8d2e1b38467',1,'Ponto::linha']]]
];
