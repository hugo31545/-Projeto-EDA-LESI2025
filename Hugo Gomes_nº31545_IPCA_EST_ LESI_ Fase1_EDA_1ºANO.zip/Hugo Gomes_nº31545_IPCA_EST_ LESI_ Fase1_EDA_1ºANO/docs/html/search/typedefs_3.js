var searchData=
[
  ['linhaarquivo_0',['LinhaArquivo',['../gestor__antenas_8h.html#a2e60bfd4125256cb09182bdeb8c374d2',1,'gestor_antenas.h']]]
];
