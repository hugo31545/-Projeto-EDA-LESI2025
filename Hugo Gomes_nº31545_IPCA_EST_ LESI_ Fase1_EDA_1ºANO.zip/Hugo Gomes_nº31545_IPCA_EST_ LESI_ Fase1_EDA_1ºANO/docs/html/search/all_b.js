var searchData=
[
  ['salvarestadobinario_0',['salvarEstadoBinario',['../estruturadedados4_8c.html#abfbdb22e2f6b3b740fc2aec85d8c3b52',1,'salvarEstadoBinario(Antena *cabeca, char *nomeArquivo):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#abfbdb22e2f6b3b740fc2aec85d8c3b52',1,'salvarEstadoBinario(Antena *cabeca, char *nomeArquivo):&#160;estruturadedados4.c']]]
];
