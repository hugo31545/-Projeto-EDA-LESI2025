var searchData=
[
  ['liberarantenas_0',['liberarAntenas',['../estruturadedados4_8c.html#af75347fa8ad8f368b1b8621593224f3b',1,'liberarAntenas(Antena *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#af75347fa8ad8f368b1b8621593224f3b',1,'liberarAntenas(Antena *cabeca):&#160;estruturadedados4.c']]],
  ['liberarcelulasmatriz_1',['liberarCelulasMatriz',['../estruturadedados4_8c.html#a533554ae99b89f64f2a357844ea2d986',1,'liberarCelulasMatriz(CelulaMatriz *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#a533554ae99b89f64f2a357844ea2d986',1,'liberarCelulasMatriz(CelulaMatriz *cabeca):&#160;estruturadedados4.c']]],
  ['liberarefeitos_2',['liberarEfeitos',['../estruturadedados4_8c.html#ad6442dfbdecdd08b47e4428db900b9d4',1,'liberarEfeitos(EfeitoNefasto *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#ad6442dfbdecdd08b47e4428db900b9d4',1,'liberarEfeitos(EfeitoNefasto *cabeca):&#160;estruturadedados4.c']]],
  ['liberarlinhasarquivo_3',['liberarLinhasArquivo',['../estruturadedados4_8c.html#a158c19b528aff97618434454c48a3893',1,'liberarLinhasArquivo(LinhaArquivo *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#a158c19b528aff97618434454c48a3893',1,'liberarLinhasArquivo(LinhaArquivo *cabeca):&#160;estruturadedados4.c']]],
  ['liberarpontos_4',['liberarPontos',['../estruturadedados4_8c.html#aef2cb5309c876fe7bb48a6d8db2df4cb',1,'liberarPontos(Ponto *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#aef2cb5309c876fe7bb48a6d8db2df4cb',1,'liberarPontos(Ponto *cabeca):&#160;estruturadedados4.c']]]
];
