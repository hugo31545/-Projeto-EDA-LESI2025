var searchData=
[
  ['antena_0',['Antena',['../struct_antena.html',1,'Antena'],['../gestor__antenas_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'Antena:&#160;gestor_antenas.h']]],
  ['atualizarcelula_1',['atualizarCelula',['../estruturadedados4_8c.html#a14eb3a75400df2e20c833e089f17fa15',1,'atualizarCelula(CelulaMatriz *cabeca, int linha, int coluna, char valor):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#a14eb3a75400df2e20c833e089f17fa15',1,'atualizarCelula(CelulaMatriz *cabeca, int linha, int coluna, char valor):&#160;estruturadedados4.c']]]
];
