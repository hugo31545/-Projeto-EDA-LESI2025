var searchData=
[
  ['efeitonefasto_0',['EfeitoNefasto',['../struct_efeito_nefasto.html',1,'EfeitoNefasto'],['../gestor__antenas_8h.html#a6167db7f1ec0c34503d24b77b3613bfa',1,'EfeitoNefasto:&#160;gestor_antenas.h']]],
  ['estruturadedados4_2ec_1',['estruturadedados4.c',['../estruturadedados4_8c.html',1,'']]],
  ['exportararquivo_2',['exportarArquivo',['../estruturadedados4_8c.html#a247149cc363804963665a45c9ada7401',1,'exportarArquivo(Antena *cabeca):&#160;estruturadedados4.c'],['../gestor__antenas_8h.html#a247149cc363804963665a45c9ada7401',1,'exportarArquivo(Antena *cabeca):&#160;estruturadedados4.c']]]
];
