var searchData=
[
  ['celulamatriz_0',['CelulaMatriz',['../gestor__antenas_8h.html#adce779b2f979b58cda3f5a29d87d18c6',1,'gestor_antenas.h']]]
];
