/**
 * @file estruturadedados4.c
 * @brief Implementação do gestor de antenas de rádio
 * 
 * Este ficheiro contém a implementação das funções para gerir um sistema
 * de antenas de rádio, calcular padrões de interferência e visualizar os efeitos.
 */

 #include "gestor_antenas.h"

/**
 * @brief Cria um novo ponto com coordenadas especificadas
 * 
 * Aloca memória para uma estrutura Ponto e inicializa com os valores fornecidos.
 * 
 * @param linha Posição vertical (linha) do ponto
 * @param coluna Posição horizontal (coluna) do ponto
 * @return Ponteiro para o Ponto criado, ou encerra o programa em caso de falha
 * 
 * @note O campo 'proximo' é sempre inicializado como NULL
 * @warning Termina o programa se a alocação de memória falhar
 */
Ponto* criarPontoNefasto(int linha, int coluna) {
    Ponto* novo = (Ponto*)malloc(sizeof(Ponto));
    if (novo == NULL) {
        printf("Erro de alocacao de memoria\n");
        exit(1);
    }
    novo->linha = linha;
    novo->coluna = coluna;
    novo->proximo = NULL;
    return novo;
}

 
/**
 * @brief Calcula os pontos de efeito entre duas antenas
 * 
 * Determina os 4 pontos de interferência gerados por duas antenas com a mesma frequência,
 * utilizando suas posições para calcular os locais afetados.
 * 
 * @param linha1 Linha da primeira antena
 * @param col1 Coluna da primeira antena
 * @param linha2 Linha da segunda antena
 * @param col2 Coluna da segunda antena
 * @return Lista ligada de Pontos afetados (deve ser liberada com liberarPontos())
 * 
 * @note Cada par de antenas gera exatamente 4 pontos de interferência
 * @see liberarPontos(), criarPonto()
 */
Ponto* calcularPontosEfeitoNefasto(int linha1, int col1, int linha2, int col2) {
    int delta_linha = linha2 - linha1;
    int delta_coluna = col2 - col1;
    
    Ponto* pontos = NULL;
    
    // Ponto 1
    pontos = criarPontoNefasto(linha1 - delta_linha, col1 - delta_coluna);
    
    // Ponto 2
    Ponto* p2 = criarPontoNefasto(linha2 + delta_linha, col2 + delta_coluna);
    p2->proximo = pontos;
    pontos = p2;
    
    return pontos;
}
 
/**
 * @brief Libera a memória de uma lista de Pontos
 * 
 * Percorre e libera todos os elementos de uma lista ligada de Pontos,
 * prevenindo vazamentos de memória.
 * 
 * @param cabeca Primeiro elemento da lista a ser liberada
 * @return NULL (sempre retorna NULL para facilitar atribuição)
 * 
 * @note Pode ser chamada com NULL sem causar erros
 * @see criarPonto(), calcularPontosEfeito()
 */
Ponto* libertarPontos(Ponto* cabeca) {
    while (cabeca != NULL) {
        Ponto* temp = cabeca;
        cabeca = cabeca->proximo;
        free(temp);
    }
    return NULL;
}
 
/**
 * @brief Cria e inicializa uma nova célula da matriz esparsa
 * 
 * Aloca memória para uma nova CelulaMatriz e inicializa seus campos com os valores
 * fornecidos. A célula criada representa uma posição específica na matriz com um valor.
 * 
 * @param linha Posição vertical (linha) da célula
 * @param coluna Posição horizontal (coluna) da célula
 * @param valor Caractere a ser armazenado na célula
 * 
 * @return Ponteiro para a célula criada
 * @retval NULL Nunca retorna NULL (encerra programa em caso de falha)
 * 
 * @warning Encerra o programa com código 1 se a alocação falhar
 * @note O campo 'proximo' é sempre inicializado como NULL
 */
/* Função para criar uma nova célula da matriz */
CelulaMatriz* criarCelulaMatriz(int linha, int coluna, char valor) {
    CelulaMatriz* nova = (CelulaMatriz*)malloc(sizeof(CelulaMatriz));
    if (nova == NULL) {
        printf("Erro de alocacao de memoria\n");
        exit(1);
    }
    nova->linha = linha;
    nova->coluna = coluna;
    nova->valor = valor;
    nova->proximo = NULL;
    return nova;
}
 
/**
 * @brief Busca uma célula na matriz esparsa pelas coordenadas
 * 
 * Percorre a lista ligada de células para encontrar uma célula específica
 * com as coordenadas (linha, coluna) fornecidas.
 * 
 * @param cabeca Primeira célula da lista ligada a ser pesquisada
 * @param linha Linha da célula desejada
 * @param coluna Coluna da célula desejada
 * 
 * @return Ponteiro para a célula encontrada
 * @retval NULL Se a célula não for encontrada
 * 
 * @note Complexidade O(n) no pior caso (lista não ordenada)
 * @see criarCelulaMatriz(), atualizarCelula()
 */
/* Função para buscar uma célula na matriz */
CelulaMatriz* ProcurarCelula(CelulaMatriz* cabeca, int linha, int coluna) {
    CelulaMatriz* atual = cabeca;
    while (atual != NULL) {
        if (atual->linha == linha && atual->coluna == coluna) {
            return atual;
        }
        atual = atual->proximo;
    }
    return NULL;
}
/**
 * @brief Atualiza ou insere uma célula na matriz esparsa
 * 
 * Atualiza o valor de uma célula existente ou cria uma nova célula se não existir,
 * mantendo a lista ligada de células da matriz esparsa.
 * 
 * @param cabeca Primeira célula da lista ligada
 * @param linha Linha da célula a atualizar/criar
 * @param coluna Coluna da célula a atualizar/criar
 * @param valor Novo valor a ser armazenado na célula
 * 
 * @return Nova cabeça da lista ligada (pode ser a mesma ou uma nova célula)
 * 
 * @note Se a célula não existir, cria uma nova e a torna a nova cabeça da lista
 * @warning Pode alterar a cabeça da lista ligada
 * @see buscarCelula(), criarCelulaMatriz()
 */
/* Função para atualizar ou criar uma célula na matriz */
CelulaMatriz* atualizarCelula(CelulaMatriz* cabeca, int linha, int coluna, char valor) {
    CelulaMatriz* celula = ProcurarCelula(cabeca, linha, coluna);
    if (celula != NULL) {
        celula->valor = valor;
        return cabeca;
    } else {
        CelulaMatriz* nova = criarCelulaMatriz(linha, coluna, valor);
        nova->proximo = cabeca;
        return nova;
    }
}

 
/**
 * @brief Calcula o número de linhas necessárias para acomodar todas as antenas
 * 
 * Percorre a lista de antenas para determinar a dimensão vertical necessária
 * para representar o sistema completo.
 * 
 * @param cabeca Ponteiro para a primeira antena na lista ligada
 * @return Número de linhas necessário (mínimo 1)
 * 
 * @note Retorna pelo menos 1 mesmo para lista vazia
 * @see calcularColunas(), mostrarMatrizAntenas()
 */
/* Função para calcular número de linhas */
int calcularNumLinhas(Antena* cabeca) {
    int linhas = 0;
    for (Antena* a = cabeca; a != NULL; a = a->proximo) {
        if (a->linha >= linhas) linhas = a->linha + 1;
    }
    if (linhas > 0) {
        return linhas;
    } else {
        return 1;
    }
}
 
 /**
 * @brief Calcula o número de colunas necessárias para acomodar todas as antenas
 * 
 * Percorre a lista ligada de antenas para determinar a dimensão horizontal
 * necessária para representar o sistema completo.
 * 
 * @param cabeca Ponteiro para o início da lista de antenas
 * @return Número de colunas necessárias (no mínimo 1)
 * 
 * @note Retorna 1 se não houver antenas ou se todas estiverem na coluna 0
 * @see calcularLinhas(), mostrarMatrizComEfeitos()
 * 
 * @code
 * Exemplo:
 * Antena* lista = ...; // lista de antenas
 * int cols = calcularColunas(lista); // obtém número de colunas
 * @endcode
 */
int calcularNumColunas(Antena* cabeca) {
    int colunas = 0;
    for (Antena* a = cabeca; a != NULL; a = a->proximo) {
        if (a->coluna >= colunas) colunas = a->coluna + 1;
    }
    if (colunas > 0) {
        return colunas;
    } else {
        return 1;
    }
}

 /**
 * @brief Insere uma nova antena no início da lista ligada
 * 
 * Aloca e inicializa uma nova estrutura Antena, inserindo-a como novo nó cabeça
 * da lista ligada. A função garante a criação de uma antena com os parâmetros
 * especificados.
 * 
 * @param cabeca Ponteiro para a atual cabeça da lista (pode ser NULL)
 * @param frequencia Caractere representando a frequência da antena
 * @param linha Posição vertical da antena no sistema
 * @param coluna Posição horizontal da antena no sistema
 * 
 * @return Ponteiro para a nova cabeça da lista (a antena recém-criada)
 * 
 * @warning Encerra o programa com código 1 em caso de falha na alocação
 * @note A nova antena é sempre inserida no início da lista
 * @see removerAntena(), liberarAntenas()
 */
/* Funções básicas */
Antena* inserirAntena(Antena* cabeca, char frequencia, int linha, int coluna) {
    Antena* nova = (Antena*)malloc(sizeof(Antena));
    if (nova == NULL) {
        printf("Erro de alocacao de memoria\n");
        exit(1);
    }
    nova->frequencia = frequencia;
    nova->linha = linha;
    nova->coluna = coluna;
    nova->proximo = cabeca;
    return nova;
}
 /**
 * @brief Remove uma antena específica da lista ligada
 * 
 * Busca e remove a antena nas coordenadas especificadas, mantendo a integridade
 * da lista ligada. Atualiza o flag de sucesso para indicar se a remoção ocorreu.
 * 
 * @param cabeca Ponteiro para a cabeça da lista de antenas
 * @param linha Coordenada vertical da antena a remover
 * @param coluna Coordenada horizontal da antena a remover
 * @param[out] sucesso Ponteiro para armazenar status da operação (true se removido)
 * 
 * @return Nova cabeça da lista (pode ser a mesma ou alterada)
 * 
 * @note A lista original permanece inalterada se a antena não for encontrada
 * @warning Não altera o parâmetro 'sucesso' se a antena não for encontrada
 * @see inserirAntena(), liberarAntenas()
 */
 
Antena* removerAntena(Antena* cabeca, int linha, int coluna, bool* sucesso) {
    Antena* atual = cabeca;
    Antena* anterior = NULL;
    *sucesso = false;
    
    while (atual != NULL && !(atual->linha == linha && atual->coluna == coluna)) {
        anterior = atual;
        atual = atual->proximo;
    }
    
    if (atual == NULL) return cabeca;
    
    *sucesso = true;
    
    if (anterior == NULL) {
        Antena* nova_cabeca = atual->proximo;
        free(atual);
        return nova_cabeca;
    } else {
        anterior->proximo = atual->proximo;
        free(atual);
        return cabeca;
    }
}
 
/**
 * @brief Identifica e exibe os pontos com efeitos de interferência entre antenas
 * 
 * Analisa todas as combinações de antenas com mesma frequência para detectar
 * e mostrar os pontos de interferência no sistema.
 * 
 * @param cabeca Ponteiro para a lista de antenas
 * @return Número total de efeitos nefastos encontrados
 * 
 * @note Exibe resultados formatados no console
 * @warning Consome memória temporária que é liberada ao final
 * @see calcularPontosEfeito(), liberarPontos(), liberarCelulasMatriz()
 * 
 * @details A função:
 * 1. Cria uma matriz esparsa com as antenas existentes
 * 2. Para cada par de antenas com mesma frequência:
 *    - Calcula os 4 pontos de interferência
 *    - Marca os pontos válidos na matriz
 * 3. Exibe os resultados agrupados por linha
 * 4. Libera toda memória auxiliar alocada
 */
int ListaTabularNefasto(Antena* cabeca) {
    if (cabeca == NULL) {
        printf("\nNenhuma antena cadastrada.\n");
        return 0;
    }

    int linhas = calcularNumLinhas(cabeca);
    int colunas = calcularNumColunas(cabeca);

    CelulaMatriz* matriz = NULL;
    
    // Preencher antenas na matriz
    for (Antena* a = cabeca; a != NULL; a = a->proximo) {
        if (a->linha < linhas && a->coluna < colunas) {
            matriz = atualizarCelula(matriz, a->linha, a->coluna, a->frequencia);
        }
    }

    EfeitoNefasto* efeitos = NULL;
    int total = 0;
    
    for (Antena* a1 = cabeca; a1 != NULL; a1 = a1->proximo) {
        for (Antena* a2 = a1->proximo; a2 != NULL; a2 = a2->proximo) {
            if (a1->frequencia == a2->frequencia) {
                Ponto* pontos = calcularPontosEfeitoNefasto(a1->linha, a1->coluna, a2->linha, a2->coluna);
                
                for (Ponto* p = pontos; p != NULL; p = p->proximo) {
                    if (p->linha >= 0 && p->coluna >= 0 && p->linha < linhas && p->coluna < colunas) {
                        CelulaMatriz* celula = ProcurarCelula(matriz, p->linha, p->coluna);
                        if (celula == NULL || celula->valor == CHAR_VAZIO) {
                            matriz = atualizarCelula(matriz, p->linha, p->coluna, CHAR_EFEITO);
                            total++;
                            
                            EfeitoNefasto* novo = (EfeitoNefasto*)malloc(sizeof(EfeitoNefasto));
                            novo->linha = p->linha;
                            novo->coluna = p->coluna;
                            novo->frequencia_origem = a1->frequencia;
                            novo->proximo = efeitos;
                            efeitos = novo;
                        }
                    }
                }
                
                pontos = libertarPontos(pontos);
            }
        }
    }

    printf("\n=== LOCAIS COM EFEITO NEFASTO (#) ===\n");
    
    // Contar efeitos por linha
    for (int i = 0; i < linhas; i++) {
        int count_linha = 0;
        CelulaMatriz* atual = matriz;
        while (atual != NULL) {
            if (atual->linha == i && atual->valor == CHAR_EFEITO) {
                count_linha++;
            }
            atual = atual->proximo;
        }
        
        if (count_linha > 0) {
            printf("linha %d --> %d#", i, count_linha);
            
            // Mostrar colunas
            atual = matriz;
            while (atual != NULL) {
                if (atual->linha == i && atual->valor == CHAR_EFEITO) {
                    printf(" (coluna %d)", atual->coluna);
                }
                atual = atual->proximo;
            }
            printf("\n");
        }
    }
    
    printf("\nTotal de efeitos nefastos (#): %d\n", total);

    matriz = libertarCelulasMatriz(matriz);
    libertarEfeitos(efeitos);
    return total;
}
 
/**
 * @brief Exibe uma representação matricial do sistema de antenas
 * 
 * Gera e mostra no console uma visualização da disposição espacial
 * de todas as antenas, representando posições vazias com CHAR_VAZIO.
 * 
 * @param cabeca Ponteiro para a lista de antenas
 * @return Número total de células exibidas (linhas × colunas)
 * 
 * @note Mostra dimensões do sistema e cada antena em sua posição correta
 * @warning Libera a matriz esparsa auxiliar após uso
 * @see calcularLinhas(), calcularColunas(), atualizarCelula()
 * 
 * @details A função:
 * 1. Calcula as dimensões necessárias
 * 2. Constrói matriz esparsa com as antenas
 * 3. Exibe a matriz formatada no console
 * 4. Libera memória auxiliar
 */
/* Funções de visualização */
int mostrarMatriz_SemNEF_Antenas(Antena* cabeca) {
    if (cabeca == NULL) {
        printf("\nNenhuma antena cadastrada.\n");
        return 0;
    }

    int linhas = calcularNumLinhas(cabeca);
    int colunas = calcularNumColunas(cabeca);

    CelulaMatriz* matriz = NULL;
    
    // Preencher matriz com as antenas
    for (Antena* a = cabeca; a != NULL; a = a->proximo) {
        if (a->linha < linhas && a->coluna < colunas) {
            matriz = atualizarCelula(matriz, a->linha, a->coluna, a->frequencia);
        }
    }

    printf("\n=== MAPA DE ANTENAS ===\n");
    printf("Dimensoes: %d linhas x %d colunas\n", linhas, colunas);
    
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            CelulaMatriz* celula = ProcurarCelula(matriz, i, j);
            if (celula != NULL) {
                printf("%c", celula->valor);
            } else {
                printf("%c", CHAR_VAZIO);
            }
        }
        printf("\n");
    }

    matriz = libertarCelulasMatriz(matriz);
    return linhas * colunas;
}
 
 /**
 * @brief Exibe o mapa completo de antenas e efeitos de interferência
 * 
 * Gera e mostra uma matriz representando todas as antenas e os pontos
 * de interferência (#) causados por pares de antenas com mesma frequência.
 * 
 * @param cabeca Ponteiro para a lista de antenas
 * @return Número total de células exibidas (linhas × colunas)
 * 
 * @note Mostra:
 *       - Antenas com seus caracteres de frequência
 *       - Pontos de interferência com CHAR_EFEITO
 *       - Posições vazias com CHAR_VAZIO
 * @warning Libera todas as estruturas temporárias após exibição
 * @see calcularPontosEfeito(), mostrarApenasEfeitos(), mostrarMatrizAntenas()
 * 
 * @details A função:
 * 1. Calcula as dimensões do sistema
 * 2. Constrói matriz esparsa com antenas
 * 3. Identifica todos os efeitos de interferência
 * 4. Exibe a matriz completa formatada
 * 5. Libera toda memória auxiliar
 */
int mostrarMatriz_Nef_Antenas(Antena* cabeca) {
    if (cabeca == NULL) {
        printf("\nNenhuma antena cadastrada.\n");
        return 0;
    }

    int linhas = calcularNumLinhas(cabeca);
    int colunas = calcularNumColunas(cabeca);

    CelulaMatriz* matriz = NULL;
    EfeitoNefasto* efeitos = NULL;
    
    // Primeiro preencher com as antenas
    for (Antena* a = cabeca; a != NULL; a = a->proximo) {
        if (a->linha < linhas && a->coluna < colunas) {
            matriz = atualizarCelula(matriz, a->linha, a->coluna, a->frequencia);
        }
    }

    // Depois calcular os efeitos
    for (Antena* a1 = cabeca; a1 != NULL; a1 = a1->proximo) {
        for (Antena* a2 = a1->proximo; a2 != NULL; a2 = a2->proximo) {
            if (a1->frequencia == a2->frequencia) {
                Ponto* pontos = calcularPontosEfeitoNefasto(a1->linha, a1->coluna, a2->linha, a2->coluna);
                
                for (Ponto* p = pontos; p != NULL; p = p->proximo) {
                    if (p->linha >= 0 && p->coluna >= 0 && p->linha < linhas && p->coluna < colunas) {
                        CelulaMatriz* celula = ProcurarCelula(matriz, p->linha, p->coluna);
                        if (celula == NULL || celula->valor == CHAR_VAZIO) {
                            matriz = atualizarCelula(matriz, p->linha, p->coluna, CHAR_EFEITO);
                            
                            EfeitoNefasto* novo = (EfeitoNefasto*)malloc(sizeof(EfeitoNefasto));
                            novo->linha = p->linha;
                            novo->coluna = p->coluna;
                            novo->frequencia_origem = a1->frequencia;
                            novo->proximo = efeitos;
                            efeitos = novo;
                        }
                    }
                }
                
                pontos = libertarPontos(pontos);
            }
        }
    }

    printf("\n=== MAPA COM EFEITOS NEFASTOS ===\n");
    printf("Dimensoes: %d linhas x %d colunas\n", linhas, colunas);
    
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            CelulaMatriz* celula = ProcurarCelula(matriz, i, j);
            if (celula != NULL) {
            printf("%c", celula->valor);
        } else {
            printf("%c", CHAR_VAZIO);
        }
        }
        printf("\n");
    }

    matriz = libertarCelulasMatriz(matriz);
    libertarEfeitos(efeitos);
    return linhas * colunas;
}
 
/**
 * @brief Carrega configuração de antenas a partir de arquivo texto
 * 
 * Lê um arquivo no formato especificado e cria uma lista de antenas correspondente.
 * 
 * @param[out] success Ponteiro para indicar sucesso/falha da operação
 * @param[out] message Buffer para mensagem de status (mínimo 100 caracteres)
 * @return Lista de antenas carregada ou NULL em caso de erro
 * 
 * @note Formato do arquivo esperado:
 *       - Cada linha representa uma linha do sistema
 *       - Caracteres separados por espaços
 *       - '.' representa posição vazia
 * @warning Aloca memória que deve ser liberada com liberarAntenas()
 * @see exportarArquivo(), liberarAntenas()
 * 
 * @details O arquivo deve estar no diretório do programa com nome "antenaex.txt"
 */
Antena* carregarArquivo(bool* success, char* message) {
    FILE *file = fopen("antenaex.txt", "r");
    if (!file) {
        strcpy(message, "Erro ao abrir o arquivo.\n");
        *success = false;
        return NULL;
    }

    LinhaArquivo* lista_linhas = NULL;
    LinhaArquivo* ultima_linha = NULL;
    char* linha = NULL;
    size_t tamanho = 0;
    ssize_t lido;
    int num_linhas = 0;
    int max_colunas = 0;

    // Lê todas as linhas do arquivo para uma lista ligada
    while ((lido = getline(&linha, &tamanho, file)) != -1) {
        // Remove o \n do final
        if (linha[lido - 1] == '\n') {
            linha[lido - 1] = '\0';
            lido--;
        }

        // Cria novo nó para a linha
        LinhaArquivo* nova_linha = malloc(sizeof(LinhaArquivo));
        nova_linha->conteudo = strdup(linha);
        nova_linha->proximo = NULL;

        // Adiciona à lista
        if (lista_linhas == NULL) {
            lista_linhas = nova_linha;
            ultima_linha = nova_linha;
        } else {
            ultima_linha->proximo = nova_linha;
            ultima_linha = nova_linha;
        }

        // Calcula número de colunas nesta linha
        int colunas = 0;
        for (int i = 0; linha[i] != '\0'; i++) {
            if (linha[i] != ' ') colunas++;
        }
        
        if (colunas > max_colunas) max_colunas = colunas;
        num_linhas++;
    }
    free(linha);
    fclose(file);

    // Verifica se leu alguma linha
    if (num_linhas == 0 || max_colunas == 0) {
        strcpy(message, "Arquivo vazio ou formato invalido.\n");
        *success = false;
        libertarLinhasArquivo(lista_linhas);
        return NULL;
    }

    // Processa as linhas para criar as antenas
    Antena* cabeca = NULL;
    LinhaArquivo* atual = lista_linhas;
    for (int i = 0; i < num_linhas && atual != NULL; i++) {
        int coluna_atual = 0;
        for (int j = 0; atual->conteudo[j] != '\0'; j++) {
            if (atual->conteudo[j] != ' ') {
                if (atual->conteudo[j] != CHAR_VAZIO) {
                    cabeca = inserirAntena(cabeca, atual->conteudo[j], i, coluna_atual);
                }
                coluna_atual++;
            }
        }
        atual = atual->proximo;
    }

    // Libera a memória das linhas do arquivo
    libertarLinhasArquivo(lista_linhas);
    
    strcpy(message, "\nDados importados com sucesso.\n");
    *success = true;
    return cabeca;
}
 
/**
 * @brief Libera a memória de uma lista de linhas de arquivo
 * 
 * Percorre e libera todos os nós de uma lista ligada de LinhaArquivo,
 * incluindo o conteúdo de cada linha.
 * 
 * @param cabeca Ponteiro para o início da lista
 * @return NULL (sempre retorna NULL para facilitar atribuição)
 * 
 * @note Função segura para lista vazia (NULL)
 * @warning Libera tanto a estrutura quanto o conteúdo das linhas
 * @see carregarArquivo()
 */
LinhaArquivo* libertarLinhasArquivo(LinhaArquivo* cabeca) {
    while (cabeca != NULL) {
        LinhaArquivo* temp = cabeca;
        cabeca = cabeca->proximo;
        free(temp->conteudo);
        free(temp);
    }
    return NULL;
}

 
 /**
 * @brief Exporta a configuração atual das antenas para um arquivo texto
 * 
 * Salva o estado atual do sistema de antenas em um arquivo no formato:
 * - Primeira linha: dimensões (linhas colunas)
 * - Linhas subsequentes: matriz de caracteres representando as antenas
 * 
 * @param cabeca Ponteiro para a lista de antenas
 * @return Número de células exportadas (linhas×colunas), ou 0 em caso de erro
 * 
 * @note Formato do arquivo:
 *       - Antenas representadas por seus caracteres de frequência
 *       - Posições vazias representadas por CHAR_VAZIO
 *       - Valores separados por espaços
 * @warning Sobrescreve o arquivo "antenaex.txt" se já existir
 * @see carregarArquivo(), calcularLinhas(), calcularColunas()
 */
int exportarArquivo(Antena* cabeca) {
    if (cabeca == NULL) {
        printf("\nNenhuma antena para exportar.\n");
        return 0;
    }
    
    int linhas = calcularNumLinhas(cabeca);
    int colunas = calcularNumColunas(cabeca);
    
    CelulaMatriz* matriz = NULL;
    
    // Preencher a matriz com as antenas
    for (Antena* a = cabeca; a != NULL; a = a->proximo) {
        if (a->linha < linhas && a->coluna < colunas) {
            matriz = atualizarCelula(matriz, a->linha, a->coluna, a->frequencia);
        }
    }
    
    FILE *file = fopen("antenaex.txt", "w");
    if (!file) {
        printf("Erro ao criar arquivo\n");
        libertarCelulasMatriz(matriz);
        return 0;
    }
    
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            CelulaMatriz* celula = ProcurarCelula(matriz, i, j);
            if (celula != NULL) {
                fprintf(file, "%c ", celula->valor);
            } else {
                fprintf(file, "%c ", CHAR_VAZIO);
            }
        }
        fprintf(file, "\n");
    }
    
    fclose(file);
    libertarCelulasMatriz(matriz);
    printf("\nDados exportados para 'antenaex.txt'.\n");
    return linhas * colunas;
}
 
 /**
 * @brief Libera toda a memória alocada para uma lista de antenas
 * 
 * Percorre recursivamente a lista ligada de antenas, liberando cada nó
 * individualmente. Retorna NULL para permitir atribuição imediata.
 * 
 * @param cabeca Ponteiro para o início da lista de antenas
 * @return NULL (para facilitar a atribuição: lista = liberarAntenas(lista))
 * 
 * @note Função segura para lista vazia (aceita NULL como entrada)
 * @warning Todas as antenas da lista são permanentemente removidas
 * @see inserirAntena(), removerAntena()
 */
/* Funções auxiliares */
Antena* libertarAntenas(Antena* cabeca) {
    while (cabeca != NULL) {
        Antena* temp = cabeca;
        cabeca = cabeca->proximo;
        free(temp);
    }
    return NULL;
}
 
/**
 * @brief Libera a memória alocada para uma lista de efeitos nefastos
 * 
 * Percorre e libera todos os elementos de uma lista ligada de estruturas EfeitoNefasto.
 * 
 * @param cabeca Ponteiro para o primeiro elemento da lista
 * @return NULL (para facilitar a atribuição: efeitos = liberarEfeitos(efeitos))
 * 
 * @note Função segura para lista vazia (aceita NULL como entrada)
 * @warning Todos os efeitos da lista são permanentemente removidos
 * @see mostrarApenasEfeitos(), mostrarMatrizComEfeitos()
 */
EfeitoNefasto* libertarEfeitos(EfeitoNefasto* cabeca) {
    while (cabeca != NULL) {
        EfeitoNefasto* temp = cabeca;
        cabeca = cabeca->proximo;
        free(temp);
    }
    return NULL;
}

/**
 * @brief Libera a memória de uma lista de células da matriz esparsa  
 * 
 * Percorre e desaloca todos os nós de uma lista ligada de CelulaMatriz.
 * 
 * @param cabeca Ponteiro para a primeira célula da lista
 * @return NULL (para permitir atribuição direta: matriz = liberarCelulasMatriz(matriz))
 * 
 * @note Função segura para lista vazia (aceita NULL como entrada)
 * @warning Todos os elementos da lista são permanentemente removidos
 * @see criarCelulaMatriz(), buscarCelula(), atualizarCelula()
 */
CelulaMatriz* libertarCelulasMatriz(CelulaMatriz* cabeca) {
    while (cabeca != NULL) {
        CelulaMatriz* temp = cabeca;
        cabeca = cabeca->proximo;
        free(temp);
    }
    return NULL;
}
 
 /**
 * @brief Salva o estado atual das antenas em um arquivo binário
 * 
 * Armazena a configuração completa do sistema de antenas em um arquivo binário
 * no formato:
 * 1. Número total de antenas (int)
 * 2. Lista de estruturas Antena (frequencia, linha, coluna)
 * 
 * @param cabeca Ponteiro para a lista de antenas
 * @param nomeArquivo Nome do arquivo binário de saída
 * 
 * @return true se salvamento bem-sucedido, false em caso de erro
 * 
 * @note Formato do arquivo:
 *       - 4 bytes: número de antenas (int)
 *       - Para cada antena:
 *         - 1 byte: frequencia (char)
 *         - 4 bytes: linha (int)
 *         - 4 bytes: coluna (int)
 * @warning Sobrescreve o arquivo se já existir
 * @see carregarEstadoBinario()
 */
bool salvarEstadoBinario(Antena *cabeca, char *nomeArquivo) {
    if (!cabeca) return false; // Nenhuma antena para salvar

    FILE *file = fopen(nomeArquivo, "wb");
    if (!file) return false; // Falha ao criar arquivo

    // Contar e salvar número total de antenas
    int total = 0;
    for (Antena *a = cabeca; a; a = a->proximo) total++;
    fwrite(&total, sizeof(int), 1, file);

    // Salvar cada antena
    for (Antena *a = cabeca; a; a = a->proximo) {
        fwrite(&a->frequencia, sizeof(char), 1, file);
        fwrite(&a->linha, sizeof(int), 1, file);
        fwrite(&a->coluna, sizeof(int), 1, file);
    }

    fclose(file);
    return true;
}
 
 /**
 * @brief Carrega um estado de antenas previamente salvo em arquivo binário
 * 
 * Recupera uma configuração de antenas a partir de um arquivo binário criado
 * pela função salvarEstadoBinario(). Solicita interativamente o nome do arquivo.
 * 
 * @return Ponteiro para a lista de antenas carregada, ou NULL em caso de falha
 * 
 * @note Formato esperado do arquivo:
 *       - 4 bytes: número total de antenas (int)
 *       - Para cada antena (sequencial):
 *         - 1 byte: frequência (char)
 *         - 4 bytes: coordenada linha (int)
 *         - 4 bytes: coordenada coluna (int)
 * @warning Interrompe a carga se encontrar qualquer erro de leitura
 * @see salvarEstadoBinario(), liberarAntenas()
 * 
 * @details A função:
 * 1. Solicita o nome do arquivo ao usuário
 * 2. Verifica integridade básica do arquivo
 * 3. Carrega todas as antenas sequencialmente
 * 4. Retorna a lista reconstruída
 */
Antena* carregarEstadoBinario() {
    // Listar arquivos binários disponíveis
    char filename[100];
    printf("\nDigite o nome do arquivo para carregar: ");
    scanf("%99s", filename);

    // Verificar se o arquivo existe


    FILE *file = fopen(filename, "rb");
    if (!file) {
        printf("Erro ao abrir arquivo binario.\n");
        return NULL;
    }

    // Ler número total de antenas
    int total_antenas;
    if (fread(&total_antenas, sizeof(int), 1, file) != 1) {
        printf("Erro na leitura do arquivo.\n");
        fclose(file);
        return NULL;
    }

    Antena* cabeca = NULL;
    for (int i = 0; i < total_antenas; i++) {
        char frequencia;
        int linha, coluna;

        if (fread(&frequencia, sizeof(char), 1, file) != 1 ||
            fread(&linha, sizeof(int), 1, file) != 1 ||
            fread(&coluna, sizeof(int), 1, file) != 1) {
            printf("Erro ao ler antena %d.\n", i);
            libertarAntenas(cabeca);
            fclose(file);
            return NULL;
        }

        cabeca = inserirAntena(cabeca, frequencia, linha, coluna);
    }

    fclose(file);
    printf("\nEstado carregado de '%s' (%d antenas).\n", filename, total_antenas);
    return cabeca;
}

 
 /**
 * @file main.c
 * @brief Programa principal de gestão de sistema de antenas
 * 
 * Implementa um menu interativo para manipulação de um sistema de antenas,
 * permitindo visualização, modificação e persistência dos dados.
 */

/**
 * @brief Função principal do programa
 * 
 * Implementa o loop principal com menu de opções para gerenciamento completo
 * do sistema de antenas, incluindo:
 * - Visualizações (mapas completos e parciais)
 * - Operações CRUD (Create, Read, Update, Delete)
 * - Persistência (carregar/salvar em diferentes formatos)
 * 
 * @return 0 em caso de encerramento normal
 * 
 * @note Estrutura do menu:
 *       1-3: Visualizações
 *       4-5: Modificações
 *       6-7: Persistência em texto
 *       8-9: Persistência binária
 *       0: Sair
 * @warning Todas as operações validam entradas e gerenciam memória adequadamente
 * 
 * @details Fluxo principal:
 * 1. Inicializa sistema
 * 2. Exibe menu interativo
 * 3. Processa opção selecionada
 * 4. Mantém consistência dos dados
 * 5. Libera recursos ao encerrar
 */
/* Menu principal */
int main() {
    Antena* antenas = NULL;
    int opcao;
    
    do {
        printf("\n=== MENU PRINCIPAL ===\n");
        printf("1. Mostrar mapa de antenas\n");
        printf("2. Mostrar mapa com efeitos nefastos\n");
        printf("3. Mostrar apenas locais com efeitos (#)\n");
        printf("4. Inserir antena\n");
        printf("5. Remover antena\n");
        printf("6. Carregar arquivo\n");
        printf("7. Exportar arquivo\n");
        printf("8. Salvar estado (binario)\n");
        printf("9. Carregar estado (binario)\n");
        printf("0. Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                mostrarMatriz_SemNEF_Antenas(antenas);
                break;
            case 2:
                mostrarMatriz_Nef_Antenas(antenas);
                break;
            case 3:
                ListaTabularNefasto(antenas);
                break;
            case 4: {
                char freq;
                int lin, col;
                printf("Frequencia (caractere): ");
                scanf(" %c", &freq);
                printf("Linha: ");
                scanf("%d", &lin);
                printf("Coluna: ");
                scanf("%d", &col);
                antenas = inserirAntena(antenas, freq, lin, col);
                break;
            }
            case 5: {
                int lin, col;
                bool sucesso;
                printf("Linha: ");
                scanf("%d", &lin);
                printf("Coluna: ");
                scanf("%d", &col);
                antenas = removerAntena(antenas, lin, col, &sucesso);
                if (sucesso) {
                    printf("Antena removida com sucesso.\n");
                } else {
                    printf("Antena nao encontrada.\n");
                }
                break;
            }
            case 6: {
                bool success;
                char message[100];
                Antena* novas = carregarArquivo(&success, message);
                printf("%s", message);
                if (success) {
                    antenas = libertarAntenas(antenas);
                    antenas = novas;
                }
                break;
            }
            case 7:
                if (exportarArquivo(antenas)) {
                    printf("Arquivo exportado com sucesso.\n");
                } else {
                    printf("Erro ao exportar arquivo.\n");
                }
                break;
            case 8: {
                char nomeArquivo[50];
                time_t now = time(NULL);
                strftime(nomeArquivo, sizeof(nomeArquivo), "estado_ANTENAS_%d%M%Y_%H%M%S.bin", localtime(&now));

                if (salvarEstadoBinario(antenas, nomeArquivo)) {
                    printf("\nEstado salvo em '%s'.\n", nomeArquivo);
                } else {
                    printf("\nErro ao salvar estado.\n");
                }
                break;
            }
            case 9: {
                Antena* novas = carregarEstadoBinario();
                if (novas) {
                    antenas = libertarAntenas(antenas);
                    antenas = novas;
                    printf("Estado carregado com sucesso.\n");
                } else {
                    printf("Erro ao carregar estado binário.\n");
                }
                break;
            }
            case 0:
                printf("Saindo...\n");
                break;
            default:
                printf("Opcao invalida!\n");
        }
    } while (opcao != 0);

    antenas = libertarAntenas(antenas);
    return 0;
}
